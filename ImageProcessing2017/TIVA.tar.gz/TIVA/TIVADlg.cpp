

#include "stdafx.h"
#include "TIVA.h"
#include "TIVADlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define State 1
/////////////////////////////////////////////////////////////////////////////////////////////////////
unsigned char RGB[485][645][3] = { 0 }; //���� �Է�(640 * 480) ���� ���(160 * 120 -> 16��)
unsigned char RGBCheck[125][165][3] = { 0 }; //���� �Է�(640 * 480)�� ����, ���θ� ���� 0,25 �ٿ� 1/16ũ��� ����� �� �迭�� ����
const char RED = 0, GREEN = 1, BLUE = 2; //RGB ������� 012
const int myWidth = 640, myHeight = 480; //640 * 480
const int HEIGHT = 120, WIDTH = 160; //160 * 120
//////////////////////////////////////////////////////////////////////////////////////////////
//***********************************�Լ� ����*************************=**********************************************************

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

BITMAPINFO BmInfo;
LPBYTE pImgBuffer;



class CAboutDlg : public CDialogEx
{	
public:
	CAboutDlg();

#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    

protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()





CTIVADlg::CTIVADlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_TIVA_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTIVADlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CTIVADlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
END_MESSAGE_MAP()



BOOL CTIVADlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	SetIcon(m_hIcon, TRUE);
	SetIcon(m_hIcon, FALSE);

	RECT m_Rect = { 0, 0, 640, 500};      
	AdjustWindowRect(&m_Rect, WS_OVERLAPPEDWINDOW, FALSE);
	int width = m_Rect.right - m_Rect.left;
	int height = m_Rect.bottom - m_Rect.top;
	this->SetWindowPos(NULL, 0, 0, width, height, SWP_NOSIZE);

	m_Cap = capCreateCaptureWindow(TEXT("Image Test"), WS_CHILD
		| WS_VISIBLE, 0, 0, 640, 480, this->m_hWnd, NULL);

	if (capSetCallbackOnFrame(m_Cap, CallbackOnFrame) == FALSE) {
		return FALSE;
	}

	if (capDriverConnect(m_Cap, 0) == FALSE) {
		return FALSE;
	}

	capPreviewRate(m_Cap, 33);
	capOverlay(m_Cap, false);
	capPreview(m_Cap, true);

	if (BmInfo.bmiHeader.biBitCount != 24) {

		BmInfo.bmiHeader.biBitCount = 24;
		BmInfo.bmiHeader.biCompression = 0;
		BmInfo.bmiHeader.biSizeImage = BmInfo.bmiHeader.biWidth *BmInfo.bmiHeader.biHeight * 3;

		capGetVideoFormat(m_Cap, &BmInfo, sizeof(BITMAPINFO));
	}


	return TRUE;  
}

void CTIVADlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}


void CTIVADlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); 
		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

HCURSOR CTIVADlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CTIVADlg::OnDestroy()
{
	CDialog::OnDestroy();

	capDriverDisconnect(m_Cap);

	if (pImgBuffer != NULL) {
		delete[] pImgBuffer;
	}
}



LRESULT CALLBACK CallbackOnFrame(HWND hWnd, LPVIDEOHDR lpVHdr)
{

	int i, j;
	for (i = 0; i < myHeight; i += 4)
	{
		for (j = 0; j < myWidth; j += 4)
		{
			RGB[i][j][BLUE] = lpVHdr->lpData[(myWidth*i + j) * 3];
			RGB[i][j][GREEN] = lpVHdr->lpData[(myWidth*i + j) * 3 + 1];
			RGB[i][j][RED] = lpVHdr->lpData[(myWidth*i + j) * 3 + 2];
		}
	}

	for (int i = 0; i < myHeight / 4; i++) {
		for (int j = 0; j < myWidth / 4; j++) {
			RGBCheck[i][j][RED] = RGB[4 * i][4 * j][RED];
			RGBCheck[i][j][GREEN] = RGB[4 * i][4 * j][GREEN];
			RGBCheck[i][j][BLUE] = RGB[4 * i][4 * j][BLUE];
		}
	}
	

	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/*
		160 * 120 �ȿ����� ����ó�� �ϸ� ��
		HEIGHT : 120;
		WIDTH : 160;
	*/

	










	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//160 * 120 ȭ���� 16�� ���
	for (int l = 0; l < 4; l++) {
		for (int k = 0; k < 4; k++) {
			for (int i = 0; i < HEIGHT; i++) {
				for (int j = 0; j < WIDTH; j++) {
					RGB[120 * k + i][160 * l + j][RED] = RGBCheck[i][j][RED];
					RGB[120 * k + i][160 * l + j][GREEN] = RGBCheck[i][j][GREEN];
					RGB[120 * k + i][160 * l + j][BLUE] = RGBCheck[i][j][BLUE];
				}
			}
		}
	}
	//*
	//160 * 120 -> 640 * 480�� ��ȯ
	/*
	for (int i = 0; i < myHeight; i+=4) {
		for (int j = 0; j < myWidth; j+=4) {
			for (int k = 0; k < 3; k++) {
				RGB[i + 1][j][k] = RGB[i][j + 1][k] = RGB[i + 1][j + 1][k] = RGB[i + 3][j + 1][k] = RGBCheck[i / 4][j / 4][k];
				RGB[i + 2][j][k] = RGB[i][j + 2][k] = RGB[i + 2][j + 2][k] = RGB[i + 3][j + 2][k] = RGBCheck[i / 4][j / 4][k];
				RGB[i + 1][j + 2][k] = RGB[i + 2][j + 1][k] = RGB[i + 3][j][k] = RGB[i + 1][j + 3][k] = RGBCheck[i / 4][j / 4][k];
				RGB[i][j + 3][k] = RGB[i][j + 3][k] = RGB[i + 3][j + 3][k] = RGB[i + 2][j + 3][k] = RGBCheck[i / 4][j / 4][k];
			}
		}
	}
	*/
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	for (i = 0; i < myHeight; i++)
	{
		for (j = 0; j < myWidth; j++)
		{
			lpVHdr->lpData[(myWidth*i + j) * 3] = RGB[i][j][BLUE];
			lpVHdr->lpData[(myWidth*i + j) * 3 + 1] = RGB[i][j][GREEN];
			lpVHdr->lpData[(myWidth*i + j) * 3 + 2] = RGB[i][j][RED];
		}
	}
	return (LRESULT)true;
}

